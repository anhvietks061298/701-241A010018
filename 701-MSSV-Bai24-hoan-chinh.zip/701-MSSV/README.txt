BAI TAP 24 - LAP TRINH WEB
Sinh vien: Ha Quang Minh
MSSV: 241A010018

CAC BUOC SU DUNG
1. Giai nen 701-MSSV.zip.
2. Thay baitap22.html va baitap23.html dang giu cho bang source code bai 22 va bai 23 that cua ban.
3. Mo index.html de kiem tra trang chu; mo baitap02.html de thu tim kiem, form va countdown.
4. Deploy len GitHub Pages hoac Netlify.
5. Cap nhat URL deploy that trong baitap03.html.

GITHUB PAGES
- Tao repository (co the dat ten 701-MSSV).
- Upload toan bo noi dung ben trong thu muc 701-MSSV len nhanh main.
- Vao Settings > Pages > Build and deployment, chon Deploy from a branch, branch main, folder /(root), Save.
- Cho GitHub build xong, mo URL hien thi trong Settings > Pages.
- Neu tai khoan/ten repo khac, URL se khac; khong dung URL mau trong baitap03.html lam URL that.

LUU Y
- baitap22.html va baitap23.html trong goi nay la trang giu cho, khong phai bai cu cua ban.
- Form chi luu ten va email mau vao LocalStorage; khong luu mat khau.
- Anh avatar la anh minh hoa tam thoi.
