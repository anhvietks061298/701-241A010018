// Bài tập 24 — JavaScript thuần, không dùng innerHTML với input người dùng.
"use strict";

const products = [
  { id: 1, name: "Tai nghe Bluetooth", price: 350000, description: "Tai nghe không dây dùng hằng ngày." },
  { id: 2, name: "Bàn phím cơ", price: 790000, description: "Bàn phím gõ êm, phù hợp học tập." },
  { id: 3, name: "Chuột không dây", price: 220000, description: "Thiết kế nhỏ gọn, dễ mang theo." },
  { id: 4, name: "Màn hình 24 inch", price: 2450000, description: "Màn hình phục vụ học tập và làm việc." },
  { id: 5, name: "Giá đỡ điện thoại", price: 95000, description: "Giá đỡ tiện lợi cho bàn học." },
  { id: 6, name: "Cáp sạc USB-C", price: 120000, description: "Cáp sạc và truyền dữ liệu." }
];

const productList = document.querySelector("#productList");
const searchInput = document.querySelector("#searchInput");
const searchStatus = document.querySelector("#searchStatus");
const clearSearch = document.querySelector("#clearSearch");

function formatPrice(value) {
  return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 }).format(value);
}

function renderProducts(items) {
  productList.replaceChildren();
  if (items.length === 0) {
    searchStatus.textContent = "Không tìm thấy sản phẩm phù hợp.";
    searchStatus.className = "status error";
    return;
  }
  searchStatus.textContent = `Tìm thấy ${items.length} sản phẩm.`;
  searchStatus.className = "status success";
  const fragment = document.createDocumentFragment();
  items.forEach((product) => {
    const article = document.createElement("article");
    article.className = "product";
    const title = document.createElement("h3");
    title.textContent = product.name;
    const description = document.createElement("p");
    description.textContent = product.description;
    const price = document.createElement("p");
    price.className = "price";
    price.textContent = formatPrice(product.price);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "button secondary";
    button.dataset.action = "detail";
    button.dataset.id = String(product.id);
    button.textContent = "Xem mã sản phẩm";
    article.append(title, description, price, button);
    fragment.append(article);
  });
  productList.append(fragment);
}

function searchProducts() {
  const keyword = searchInput.value.trim().toLocaleLowerCase("vi");
  const filtered = products.filter((product) => product.name.toLocaleLowerCase("vi").includes(keyword));
  renderProducts(filtered);
}
searchInput.addEventListener("input", searchProducts);
clearSearch.addEventListener("click", () => {
  searchInput.value = "";
  searchProducts();
  searchInput.focus();
});

// Event Delegation: chỉ cần một listener cho danh sách, kể cả khi danh sách được vẽ lại.
productList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action='detail']");
  if (!button || !productList.contains(button)) return;
  const product = products.find((item) => item.id === Number(button.dataset.id));
  if (product) window.alert(`Sản phẩm: ${product.name}\nMã sản phẩm: ${product.id}`);
});
renderProducts(products);

// Form: kiểm tra dữ liệu trước khi lưu. Không lưu mật khẩu trong LocalStorage.
const registerForm = document.querySelector("#registerForm");
const formMessage = document.querySelector("#formMessage");
registerForm.addEventListener("submit", (event) => {
  event.preventDefault();
  formMessage.textContent = "";
  formMessage.className = "status";

  const fullName = document.querySelector("#fullName").value.trim();
  const email = document.querySelector("#email").value.trim();
  const password = document.querySelector("#password").value;
  const agreed = document.querySelector("#agree").checked;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

  if (fullName.length < 2) {
    showFormError("Vui lòng nhập họ tên có ít nhất 2 ký tự.");
    return;
  }
  if (!emailPattern.test(email)) {
    showFormError("Email chưa đúng định dạng.");
    return;
  }
  if (!passwordPattern.test(password)) {
    showFormError("Mật khẩu cần ít nhất 8 ký tự, có chữ hoa, chữ thường và số.");
    return;
  }
  if (!agreed) {
    showFormError("Bạn cần đồng ý với điều khoản trước khi đăng ký.");
    return;
  }

  try {
    const savedUsers = JSON.parse(localStorage.getItem("bai24_users") || "[]");
    savedUsers.push({ fullName, email, registeredAt: new Date().toISOString() });
    localStorage.setItem("bai24_users", JSON.stringify(savedUsers));
    formMessage.textContent = "Đăng ký thành công! Tên và email đã được lưu trên thiết bị này.";
    formMessage.className = "status success";
    registerForm.reset();
  } catch (error) {
    showFormError("Không thể lưu dữ liệu trên trình duyệt này. Hãy kiểm tra cài đặt lưu trữ.");
  }
});
function showFormError(message) {
  formMessage.textContent = message;
  formMessage.className = "status error";
}

// Countdown: dùng deadline và setInterval, đồng thời dọn interval khi dừng/hết giờ.
const countdownDisplay = document.querySelector("#countdown");
const startTimer = document.querySelector("#startTimer");
const pauseTimer = document.querySelector("#pauseTimer");
const resetTimer = document.querySelector("#resetTimer");
const timerStatus = document.querySelector("#timerStatus");
const INITIAL_SECONDS = 10 * 60;
let remainingSeconds = INITIAL_SECONDS;
let deadline = null;
let timerInterval = null;
let hasAlerted = false;

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${secs}`;
}
function drawTimer() {
  countdownDisplay.textContent = formatTime(remainingSeconds);
  countdownDisplay.classList.toggle("warning", remainingSeconds > 0 && remainingSeconds < 60);
}
function stopInterval() {
  if (timerInterval !== null) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}
function tick() {
  remainingSeconds = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
  drawTimer();
  if (remainingSeconds <= 0) {
    stopInterval();
    deadline = null;
    timerStatus.textContent = "Đã hết thời gian.";
    startTimer.disabled = true;
    if (!hasAlerted) {
      hasAlerted = true;
      window.alert("Đã hết 10 phút!");
    }
  }
}
startTimer.addEventListener("click", () => {
  if (timerInterval !== null || remainingSeconds <= 0) return;
  deadline = Date.now() + remainingSeconds * 1000;
  timerStatus.textContent = "Đồng hồ đang chạy.";
  timerInterval = window.setInterval(tick, 250);
  tick();
});
pauseTimer.addEventListener("click", () => {
  if (timerInterval === null) return;
  tick();
  stopInterval();
  deadline = null;
  timerStatus.textContent = "Đã tạm dừng.";
});
resetTimer.addEventListener("click", () => {
  stopInterval();
  deadline = null;
  remainingSeconds = INITIAL_SECONDS;
  hasAlerted = false;
  startTimer.disabled = false;
  timerStatus.textContent = "Đã đặt lại về 10:00.";
  drawTimer();
});
drawTimer();
