```javascript
// Hàm tính tổng thanh toán
function calculateTotal(orderTotal) {

    let shippingFee;

    if (orderTotal > 50) {
        shippingFee = 0;
    } else {
        shippingFee = 5;
    }

    return orderTotal + shippingFee;
}


// Lấy các phần tử HTML
const orderTotal = document.getElementById("orderTotal");
const button = document.getElementById("calculateButton");
const result = document.getElementById("result");


// Khi bấm nút
button.addEventListener("click", function() {

    const total = Number(orderTotal.value);

    const finalTotal = calculateTotal(total);

    result.textContent =
        "Tổng thanh toán: $" + finalTotal;

});
```