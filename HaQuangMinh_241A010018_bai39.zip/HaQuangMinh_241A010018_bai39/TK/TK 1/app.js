```javascript
const form = document.getElementById("registerForm");

form.addEventListener("submit", function(event) {

    // Không cho trang web reload
    event.preventDefault();

    // Lấy dữ liệu từ form
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Hiển thị thông tin ra Console
    console.log("Họ và tên:", name);
    console.log("Email:", email);
    console.log("Mật khẩu:", password);

});
```