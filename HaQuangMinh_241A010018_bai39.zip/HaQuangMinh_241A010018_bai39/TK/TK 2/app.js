```javascript
const agree = document.getElementById("agree");
const submitButton = document.getElementById("submitButton");

agree.addEventListener("change", function() {

    if (agree.checked) {
        submitButton.disabled = false;
    } else {
        submitButton.disabled = true;
    }

});
```