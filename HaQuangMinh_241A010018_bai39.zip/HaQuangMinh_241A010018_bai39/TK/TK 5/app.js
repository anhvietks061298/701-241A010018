```javascript
const title = document.querySelector(".accordion-title");
const content = document.querySelector(".accordion-content");

title.addEventListener("click", function() {

    content.classList.toggle("active");

});
```