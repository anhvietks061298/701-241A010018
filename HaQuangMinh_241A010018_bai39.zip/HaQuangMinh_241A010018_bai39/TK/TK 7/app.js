```javascript
// Hàm tạo mật khẩu ngẫu nhiên dài 8 ký tự
function generatePassword() {

    const characters = "abcdefghijklmnopqrstuvwxyz0123456789";

    let password = "";

    for (let i = 0; i < 8; i++) {

        const randomIndex =
            Math.floor(Math.random() * characters.length);

        password += characters[randomIndex];
    }

    return password;
}


// Lấy các phần tử HTML
const button = document.getElementById("generateButton");
const result = document.getElementById("result");


// Khi bấm nút
button.addEventListener("click", function() {

    const password = generatePassword();

    result.textContent = password;

});
```