```javascript
// Lấy tất cả các nút Tab
const tabButtons = document.querySelectorAll(".tab-button");

// Lấy tất cả nội dung Tab
const tabContents = document.querySelectorAll(".tab-content");


// Duyệt qua từng nút
tabButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        // Xóa class active khỏi tất cả các nút
        tabButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });


        // Xóa class active khỏi tất cả nội dung
        tabContents.forEach(function(content) {
            content.classList.remove("active");
        });


        // Thêm active cho nút vừa bấm
        button.classList.add("active");


        // Lấy id của nội dung cần hiển thị
        const tabId = button.getAttribute("data-tab");


        // Hiển thị nội dung tương ứng
        document.getElementById(tabId).classList.add("active");

    });

});
```