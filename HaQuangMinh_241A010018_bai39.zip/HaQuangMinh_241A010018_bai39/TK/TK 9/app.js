```javascript
// Lấy phần tử hiển thị thời gian
const clock = document.getElementById("clock");

// Hàm hiển thị thời gian
function updateClock() {

    const now = new Date();

    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    clock.textContent =
        hours + ":" + minutes + ":" + seconds;
}

// Hiển thị ngay khi mở trang
updateClock();

// Cập nhật mỗi 1 giây
setInterval(updateClock, 1000);
```