```javascript
// Khai báo mảng
const numbers = [2, 4, 6, 8, 10, 12];

// Hiển thị mảng ban đầu
document.getElementById("original").textContent =
    "Mảng ban đầu: " + numbers.join(", ");


// filter(): lấy các số lớn hơn 5
const filteredNumbers = numbers.filter(function(number) {
    return number > 5;
});

document.getElementById("filtered").textContent =
    "Các số lớn hơn 5: " + filteredNumbers.join(", ");


// map(): nhân mỗi phần tử với 2
const mappedNumbers = filteredNumbers.map(function(number) {
    return number * 2;
});

document.getElementById("mapped").textContent =
    "Sau khi nhân 2: " + mappedNumbers.join(", ");
```