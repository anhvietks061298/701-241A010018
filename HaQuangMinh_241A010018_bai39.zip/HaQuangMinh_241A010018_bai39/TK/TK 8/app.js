```javascript
// Hàm chuyển Hex sang RGB
function hexToRGB(hex) {

    // Bỏ dấu # nếu có
    hex = hex.replace("#", "");

    // Lấy giá trị Red
    const r = parseInt(hex.substring(0, 2), 16);

    // Lấy giá trị Green
    const g = parseInt(hex.substring(2, 4), 16);

    // Lấy giá trị Blue
    const b = parseInt(hex.substring(4, 6), 16);

    return "RGB(" + r + ", " + g + ", " + b + ")";
}


// Lấy các phần tử HTML
const hexInput = document.getElementById("hexInput");
const button = document.getElementById("convertButton");
const result = document.getElementById("result");


// Khi bấm nút
button.addEventListener("click", function() {

    const hex = hexInput.value;

    const rgb = hexToRGB(hex);

    result.textContent = rgb;

});
```