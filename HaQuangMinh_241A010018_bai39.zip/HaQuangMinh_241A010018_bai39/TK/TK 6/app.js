```javascript
// Hàm kiểm tra số nguyên tố
function isPrime(number) {

    if (number < 2) {
        return false;
    }

    for (let i = 2; i < number; i++) {

        if (number % i === 0) {
            return false;
        }

    }

    return true;
}


// Lấy thẻ div
const result = document.getElementById("result");


// Tìm các số nguyên tố từ 1 đến 100
for (let number = 1; number <= 100; number++) {

    if (isPrime(number)) {

        result.innerHTML += number + " ";

    }

}
```