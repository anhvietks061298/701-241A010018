```javascript
// Hàm chuyển đổi C sang F
function convertCtoF(C) {
    return C * 1.8 + 32;
}

// Lấy các phần tử HTML
const celsius = document.getElementById("celsius");
const button = document.getElementById("convertButton");
const result = document.getElementById("result");

// Khi bấm nút
button.addEventListener("click", function() {

    const C = Number(celsius.value);

    const F = convertCtoF(C);

    result.textContent = C + "°C = " + F + "°F";

});
```