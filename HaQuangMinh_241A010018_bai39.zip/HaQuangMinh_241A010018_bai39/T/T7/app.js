```javascript
// Khai báo mảng
const numbers = [1, 5, 10, 2];

// Tính tổng
let sum = 0;

for (let i = 0; i < numbers.length; i++) {
    sum += numbers[i];
}

// Hiển thị kết quả
document.getElementById("result").textContent =
    "Tổng của mảng là: " + sum;
```