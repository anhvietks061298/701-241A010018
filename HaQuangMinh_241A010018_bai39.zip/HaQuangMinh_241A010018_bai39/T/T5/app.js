```javascript
let time = 10;
let timer;

const countdown = document.getElementById("countdown");
const startButton = document.getElementById("startButton");

startButton.addEventListener("click", function() {

    // Không cho chạy nhiều đồng hồ cùng lúc
    clearInterval(timer);

    time = 10;
    countdown.textContent = time;

    // Đếm mỗi 1 giây
    timer = setInterval(function() {

        time--;

        countdown.textContent = time;

        // Khi về 0 thì dừng
        if (time === 0) {

            clearInterval(timer);

        }

    }, 1000);

});
```