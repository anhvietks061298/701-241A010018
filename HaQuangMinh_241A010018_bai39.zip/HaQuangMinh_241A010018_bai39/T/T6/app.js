```javascript
const numberInput = document.getElementById("numberInput");
const checkButton = document.getElementById("checkButton");
const result = document.getElementById("result");

checkButton.addEventListener("click", function() {

    const number = Number(numberInput.value);

    if (number % 2 === 0) {
        result.textContent = "Đây là số chẵn";
    } else {
        result.textContent = "Đây là số lẻ";
    }

});
```