```javascript
const email = document.getElementById("email");
const button = document.getElementById("checkButton");
const result = document.getElementById("result");

button.addEventListener("click", function() {

    const value = email.value;

    if (value.includes("@") && value.includes(".")) {
        result.textContent = "Email hợp lệ";
    } else {
        result.textContent = "Email không hợp lệ";
    }

});
```