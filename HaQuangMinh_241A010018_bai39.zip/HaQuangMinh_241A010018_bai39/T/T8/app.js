```javascript
// Số cần tạo bảng cửu chương
const number = 7;

// Lấy thẻ div
const result = document.getElementById("result");

// Tạo bảng cửu chương
for (let i = 1; i <= 10; i++) {

    result.innerHTML +=
        number + " x " + i + " = " + (number * i) + "<br>";

}
```