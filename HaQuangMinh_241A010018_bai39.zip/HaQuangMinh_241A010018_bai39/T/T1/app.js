```javascript
let count = 3;

const button = document.getElementById("addButton");
const list = document.getElementById("myList");

button.addEventListener("click", function() {

    // Tạo phần tử li mới
    const newItem.textContent = "Mục " + count;

    // Gán nội dung cho li
    newItem.textContent = "Mục " + count;

    // Thêm li vào ul
    list.appendChild(newItem);

    // Tăng số thứ tự
    count++;
});
```