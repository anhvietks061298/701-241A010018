```javascript
const input = document.getElementById("myInput");
const result = document.getElementById("result");

input.addEventListener("input", function() {

    result.textContent = input.value;

});
```