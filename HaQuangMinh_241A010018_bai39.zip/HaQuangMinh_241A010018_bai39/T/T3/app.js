```javascript
const search = document.getElementById("search");
const list = document.getElementById("myList");

function filterList() {

    // Lấy từ khóa người dùng nhập
    const keyword = search.value.toLowerCase();

    // Lấy tất cả các thẻ li
    const items = list.getElementsByTagName("li");

    // Duyệt qua từng li
    for (let i = 0; i < items.length; i++) {

        const text = items[i].textContent.toLowerCase();

        // Kiểm tra nội dung có chứa từ khóa không
        if (text.includes(keyword)) {
            items[i].style.display = "";
        } else {
            items[i].style.display = "none";
        }
    }
}

// Thực hiện lọc ngay khi người dùng gõ
search.addEventListener("input", filterList);
```