```javascript
// Mảng chứa URL hình ảnh
const images = [
    "https://picsum.photos/id/10/500/300",
    "https://picsum.photos/id/20/500/300",
    "https://picsum.photos/id/30/500/300",
    "https://picsum.photos/id/40/500/300"
];

// Vị trí ảnh hiện tại
let currentIndex = 0;

// Lấy các phần tử HTML
const sliderImage = document.getElementById("sliderImage");
const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");


// Hiển thị ảnh
function showImage() {
    sliderImage.src = images[currentIndex];
}


// Nút Trước
prevButton.addEventListener("click", function() {

    currentIndex--;

    if (currentIndex < 0) {
        currentIndex = images.length - 1;
    }

    showImage();
});


// Nút Tiếp
nextButton.addEventListener("click", function() {

    currentIndex++;

    if (currentIndex >= images.length) {
        currentIndex = 0;
    }

    showImage();
});
```