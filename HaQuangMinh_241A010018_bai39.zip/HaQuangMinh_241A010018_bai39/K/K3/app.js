```javascript
const form = document.getElementById("registerForm");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    const password =
        document.getElementById("password").value;

    const confirmPassword =
        document.getElementById("confirmPassword").value;

    const result =
        document.getElementById("result");


    if (password === confirmPassword) {

        result.textContent = "Mật khẩu khớp!";

    } else {

        result.textContent = "Mật khẩu không khớp!";

    }

});
```