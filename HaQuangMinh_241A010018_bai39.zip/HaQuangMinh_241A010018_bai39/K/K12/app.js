```javascript
fetch("https://jsonplaceholder.typicode.com/posts/1")
    .then(function(response) {

        return response.json();

    })
    .then(function(data) {

        document.getElementById("result").textContent =
            "Tiêu đề: " + data.title;

    })
    .catch(function(error) {

        document.getElementById("result").textContent =
            "Có lỗi xảy ra.";

        console.log(error);

    });
```