```javascript
const salary = document.getElementById("salary");
const days = document.getElementById("days");
const button = document.getElementById("calculate");
const result = document.getElementById("result");

button.addEventListener("click", function() {

    const basicSalary = Number(salary.value);
    const workDays = Number(days.value);

    const realSalary =
        basicSalary / 26 * workDays;

    result.textContent =
        "Lương thực nhận: " +
        realSalary.toFixed(2);

});
```