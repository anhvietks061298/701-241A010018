```javascript
const box = document.getElementById("box");

let topPosition = 200;

document.addEventListener("keydown", function(event) {

    if (event.key === "ArrowUp") {

        topPosition -= 10;

    }

    if (event.key === "ArrowDown") {

        topPosition += 10;

    }

    box.style.top = topPosition + "px";

});
```