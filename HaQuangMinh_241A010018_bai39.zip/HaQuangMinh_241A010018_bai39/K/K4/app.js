```javascript
// Tạo danh sách 50 mục
const items = [];

for (let i = 1; i <= 50; i++) {
    items.push("Mục " + i);
}


// Số mục mỗi trang
const itemsPerPage = 10;

// Trang hiện tại
let currentPage = 1;


const list = document.getElementById("list");
const pagination = document.getElementById("pagination");


// Hiển thị danh sách
function displayItems() {

    list.innerHTML = "";

    const start =
        (currentPage - 1) * itemsPerPage;

    const end =
        start + itemsPerPage;

    const currentItems =
        items.slice(start, end);


    currentItems.forEach(function(item) {

        const li = document.createElement("li");

        li.textContent = item;

        list.appendChild(li);

    });
}


// Tạo nút phân trang
function createPagination() {

    pagination.innerHTML = "";

    const totalPages =
        Math.ceil(items.length / itemsPerPage);


    for (let i = 1; i <= totalPages; i++) {

        const button =
            document.createElement("button");

        button.textContent = i;


        button.addEventListener("click", function() {

            currentPage = i;

            displayItems();

        });


        pagination.appendChild(button);

    }
}


// Chạy chương trình
displayItems();
createPagination();
```