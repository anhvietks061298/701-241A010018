```javascript
const date1 = document.getElementById("date1");
const date2 = document.getElementById("date2");
const button = document.getElementById("calculate");
const result = document.getElementById("result");

button.addEventListener("click", function() {

    const firstDate = new Date(date1.value);
    const secondDate = new Date(date2.value);

    const difference =
        Math.abs(secondDate - firstDate);

    const days =
        Math.ceil(difference / (1000 * 60 * 60 * 24));

    result.textContent =
        "Khoảng cách: " + days + " ngày";

});
```