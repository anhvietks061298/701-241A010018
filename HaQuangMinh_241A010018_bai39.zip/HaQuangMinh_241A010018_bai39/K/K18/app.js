```javascript
const openModal = document.getElementById("openModal");
const closeModal = document.getElementById("closeModal");
const modal = document.getElementById("modal");


// Mở Modal
openModal.addEventListener("click", function() {

    modal.classList.add("show");

});


// Đóng Modal
closeModal.addEventListener("click", function() {

    modal.classList.remove("show");

});


// Đóng bằng phím ESC
document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {

        modal.classList.remove("show");

    }

});
```