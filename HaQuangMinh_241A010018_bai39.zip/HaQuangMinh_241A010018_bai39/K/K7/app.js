```javascript
const parallax = document.getElementById("parallax");

window.addEventListener("scroll", function() {

    const scrollPosition = window.scrollY;

    parallax.style.backgroundPositionY =
        (scrollPosition * 0.5) + "px";

});
```