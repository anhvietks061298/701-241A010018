```javascript
const form = document.getElementById("form");
const errors = document.getElementById("errors");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    let errorList = [];

    // Kiểm tra tên
    if (name === "") {
        errorList.push("Tên không được để trống.");
    }

    // Kiểm tra email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
        errorList.push("Email không hợp lệ.");
    }

    // Kiểm tra mật khẩu
    if (password.length < 8) {
        errorList.push("Mật khẩu phải có ít nhất 8 ký tự.");
    }


    // Hiển thị tất cả lỗi
    if (errorList.length > 0) {

        errors.innerHTML = "";

        errorList.forEach(function(error) {

            const p = document.createElement("p");

            p.textContent = error;

            errors.appendChild(p);

        });

    } else {

        errors.textContent = "Đăng ký thành công!";

    }

});
```