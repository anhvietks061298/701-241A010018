```javascript
const players = [
    { name: "An", score: 80 },
    { name: "Bình", score: 95 },
    { name: "Cường", score: 70 },
    { name: "Dũng", score: 90 }
];

const playerList = document.getElementById("playerList");
const scoreHeader = document.getElementById("scoreHeader");

let ascending = false;


// Hiển thị bảng
function displayPlayers() {

    playerList.innerHTML = "";

    players.forEach(function(player) {

        const row = document.createElement("tr");

        row.innerHTML =
            "<td>" + player.name + "</td>" +
            "<td>" + player.score + "</td>";

        playerList.appendChild(row);

    });
}


// Click vào Điểm
scoreHeader.addEventListener("click", function() {

    players.sort(function(a, b) {

        if (ascending) {
            return a.score - b.score;
        } else {
            return b.score - a.score;
        }

    });

    ascending = !ascending;

    displayPlayers();

});


displayPlayers();
```