```javascript
const canvas = document.getElementById("canvas");

const ctx = canvas.getContext("2d");


// Bắt đầu vẽ
ctx.beginPath();

ctx.moveTo(200, 50);

ctx.lineTo(100, 200);

ctx.lineTo(300, 200);

ctx.closePath();


// Vẽ đường viền
ctx.stroke();
```