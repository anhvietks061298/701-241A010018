```javascript
const image = document.getElementById("image");


// Di chuột vào
image.addEventListener("mouseover", function() {

    image.classList.add("zoom");

});


// Di chuột ra
image.addEventListener("mouseout", function() {

    image.classList.remove("zoom");

});
```