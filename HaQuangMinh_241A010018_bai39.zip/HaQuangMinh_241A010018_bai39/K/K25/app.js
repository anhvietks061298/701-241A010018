// Chuỗi JSON
const jsonString = `{
    "name": "Nguyen Van A",
    "age": 20,
    "class": "CNTT",
    "score": 8.5
}`;


// Chuyển JSON thành Object
const student = JSON.parse(jsonString);


// Hiển thị dữ liệu
const result = document.getElementById("result");

result.innerHTML =
    "<p>Họ tên: " + student.name + "</p>" +
    "<p>Tuổi: " + student.age + "</p>" +
    "<p>Lớp: " + student.class + "</p>" +
    "<p>Điểm: " + student.score + "</p>";
