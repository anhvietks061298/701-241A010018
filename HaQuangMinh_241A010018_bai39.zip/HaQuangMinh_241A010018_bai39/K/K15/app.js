```javascript
const container = document.getElementById("container");

document.getElementById("twoColumns")
    .addEventListener("click", function() {

        container.style.gridTemplateColumns =
            "repeat(2, 1fr)";

    });


document.getElementById("threeColumns")
    .addEventListener("click", function() {

        container.style.gridTemplateColumns =
            "repeat(3, 1fr)";

    });


document.getElementById("fourColumns")
    .addEventListener("click", function() {

        container.style.gridTemplateColumns =
            "repeat(4, 1fr)";

    });
```