```javascript
const box = document.getElementById("box");

let isDragging = false;

let offsetX = 0;
let offsetY = 0;


// Khi nhấn chuột
box.addEventListener("mousedown", function(event) {

    isDragging = true;

    offsetX = event.clientX - box.offsetLeft;
    offsetY = event.clientY - box.offsetTop;

});


// Khi di chuyển chuột
document.addEventListener("mousemove", function(event) {

    if (isDragging) {

        box.style.left =
            (event.clientX - offsetX) + "px";

        box.style.top =
            (event.clientY - offsetY) + "px";

    }

});


// Khi thả chuột
document.addEventListener("mouseup", function() {

    isDragging = false;

});
```