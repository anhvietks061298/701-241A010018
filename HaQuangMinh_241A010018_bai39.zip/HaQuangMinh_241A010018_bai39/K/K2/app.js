```javascript
// Lấy dữ liệu từ localStorage
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

const taskInput = document.getElementById("taskInput");
const addButton = document.getElementById("addButton");
const taskList = document.getElementById("taskList");


// Lưu dữ liệu
function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}


// Hiển thị danh sách
function displayTasks() {

    taskList.innerHTML = "";

    tasks.forEach(function(task, index) {

        const li = document.createElement("li");

        li.textContent = task.name;

        // Nếu đã hoàn thành
        if (task.completed) {
            li.style.textDecoration = "line-through";
        }


        // Nút hoàn thành
        const doneButton = document.createElement("button");

        doneButton.textContent = "Hoàn thành";

        doneButton.addEventListener("click", function() {

            tasks[index].completed = !tasks[index].completed;

            saveTasks();
            displayTasks();

        });


        // Nút xóa
        const deleteButton = document.createElement("button");

        deleteButton.textContent = "Xóa";

        deleteButton.addEventListener("click", function() {

            tasks.splice(index, 1);

            saveTasks();
            displayTasks();

        });


        li.appendChild(doneButton);
        li.appendChild(deleteButton);

        taskList.appendChild(li);

    });
}


// Thêm công việc
addButton.addEventListener("click", function() {

    const taskName = taskInput.value.trim();

    if (taskName === "") {
        return;
    }

    tasks.push({
        name: taskName,
        completed: false
    });

    taskInput.value = "";

    saveTasks();
    displayTasks();

});


// Hiển thị dữ liệu khi mở trang
displayTasks();
```