```javascript
const text =
    "Chào mừng bạn đến với trang web của tôi!";

const textElement =
    document.getElementById("text");

let index = 0;


function typeText() {

    if (index < text.length) {

        textElement.textContent += text[index];

        index++;

        setTimeout(typeText, 100);

    }

}

typeText();
```