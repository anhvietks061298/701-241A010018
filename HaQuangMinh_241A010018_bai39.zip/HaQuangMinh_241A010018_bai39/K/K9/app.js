```javascript
const display = document.getElementById("display");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const resetButton = document.getElementById("reset");

let startTime = 0;
let elapsedTime = 0;
let timer = null;


// Hiển thị thời gian
function updateDisplay() {

    const minutes = Math.floor(elapsedTime / 60000);

    const seconds =
        Math.floor((elapsedTime % 60000) / 1000);

    const milliseconds =
        elapsedTime % 1000;

    display.textContent =
        String(minutes).padStart(2, "0") + ":" +
        String(seconds).padStart(2, "0") + ":" +
        String(milliseconds).padStart(3, "0");
}


// Bắt đầu
startButton.addEventListener("click", function() {

    if (timer !== null) {
        return;
    }

    startTime = Date.now() - elapsedTime;

    timer = setInterval(function() {

        elapsedTime = Date.now() - startTime;

        updateDisplay();

    }, 10);

});


// Dừng
stopButton.addEventListener("click", function() {

    clearInterval(timer);

    timer = null;

});


// Đặt lại
resetButton.addEventListener("click", function() {

    clearInterval(timer);

    timer = null;
    elapsedTime = 0;

    updateDisplay();

});
```