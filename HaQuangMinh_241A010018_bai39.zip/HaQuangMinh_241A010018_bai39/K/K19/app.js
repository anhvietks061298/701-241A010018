```javascript
const button = document.getElementById("showToast");
const toast = document.getElementById("toast");

button.addEventListener("click", function() {

    toast.textContent = "Thao tác thành công!";

    toast.classList.add("show");


    setTimeout(function() {

        toast.classList.remove("show");

    }, 3000);

});
```