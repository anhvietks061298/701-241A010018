```javascript
const link = document.getElementById("aboutLink");

link.addEventListener("click", function(event) {

    event.preventDefault();

    const target = document.getElementById("about");

    target.scrollIntoView({
        behavior: "smooth"
    });

});
```