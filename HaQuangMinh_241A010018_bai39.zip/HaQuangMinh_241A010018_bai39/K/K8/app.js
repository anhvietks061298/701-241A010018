```javascript
const weight = document.getElementById("weight");
const height = document.getElementById("height");
const button = document.getElementById("calculate");
const result = document.getElementById("result");

function calculateBMI(weight, height) {

    return weight / (height * height);

}

button.addEventListener("click", function() {

    const w = Number(weight.value);
    const h = Number(height.value);

    if (w <= 0 || h <= 0) {
        result.textContent = "Vui lòng nhập số hợp lệ.";
        return;
    }

    const bmi = calculateBMI(w, h);

    let classification;

    if (bmi < 18.5) {
        classification = "Thiếu cân";
    } else if (bmi < 25) {
        classification = "Bình thường";
    } else {
        classification = "Thừa cân";
    }

    result.textContent =
        "BMI: " + bmi.toFixed(2) +
        " - " + classification;

});
```