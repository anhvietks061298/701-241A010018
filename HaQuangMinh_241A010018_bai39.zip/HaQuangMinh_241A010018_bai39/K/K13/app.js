```javascript
const likeButton = document.getElementById("likeButton");
const count = document.getElementById("count");

let liked = localStorage.getItem("liked") === "true";
let likeCount = Number(localStorage.getItem("likeCount")) || 0;

count.textContent = likeCount;


// Nếu đã thích
if (liked) {
    likeButton.disabled = true;
    likeButton.textContent = "Đã thích";
}


// Khi bấm Thích
likeButton.addEventListener("click", function() {

    if (!liked) {

        likeCount++;

        liked = true;

        localStorage.setItem("likeCount", likeCount);
        localStorage.setItem("liked", "true");

        count.textContent = likeCount;

        likeButton.disabled = true;
        likeButton.textContent = "Đã thích";

    }

});
```