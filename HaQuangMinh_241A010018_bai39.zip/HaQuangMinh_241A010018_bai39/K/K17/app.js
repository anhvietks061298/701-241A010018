```javascript
const secretNumber =
    Math.floor(Math.random() * 100) + 1;

let count = 0;

const guessInput = document.getElementById("guessInput");
const guessButton = document.getElementById("guessButton");
const result = document.getElementById("result");
const countDisplay = document.getElementById("count");


guessButton.addEventListener("click", function() {

    const guess = Number(guessInput.value);

    count++;

    countDisplay.textContent = count;


    if (guess < secretNumber) {

        result.textContent = "Lớn hơn";

    } else if (guess > secretNumber) {

        result.textContent = "Nhỏ hơn";

    } else {

        result.textContent =
            "Chính xác! Bạn đã đoán đúng.";

        guessButton.disabled = true;

    }

});
```